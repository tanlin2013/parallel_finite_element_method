#!/bin/sh
#PJM -L rscgrp=lecture
#PJM -L node=1
#PJM --mpi proc=1
#PJM -L elapse=00:15:00
#PJM -g gt00
#PJM -j
#PJM -e err
#PJM -o 2d-2xb.lst

module unload intel/2019.5.281
module load intel/2018.3.222
mpiexec.hydra -n ${PJM_MPI_PROC} ./2d-2xb
