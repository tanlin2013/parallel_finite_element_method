/******************************************************************************
*         Allocate function                                                   *
*******************************************************************************/
void* allocate_vector  (int,int);
void  deallocate_vector(void*);
void** allocate_matrix (int,int,int);
void deallocate_matrix (void**);




