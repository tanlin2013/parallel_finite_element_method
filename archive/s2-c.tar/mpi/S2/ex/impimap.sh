#!/bin/sh

numactl --localalloc $@
