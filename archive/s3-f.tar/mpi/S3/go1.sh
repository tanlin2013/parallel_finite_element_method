#!/bin/sh

#PBS -q u-lecture
#PBS -N test
#PBS -l select=1:mpiprocs=1
#PBS -Wgroup_list=gt00
#PBS -l walltime=00:05:00
#PBS -e err
#PBS -o test.lst

cd $PBS_O_WORKDIR
. /etc/profile.d/modules.sh

mpirun ./impimap.sh ./a.out
