#define KINT         int
#define KREAL        double 
typedef struct char_length{
	char name[64];
}CHAR_LENGTH;
typedef struct char80{
	char name[80];
}CHAR80;
