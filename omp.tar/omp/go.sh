#!/bin/sh
#PJM -L "node=1"
#PJM -L "elapse=00:10:00"
#PJM -L "rscgrp=lecture2"
#PJM -g "gt82"
#PJM -j
#PJM -o "t0-01.lst"

export OMP_NUM_THREADS=1
./a.out < INPUT.DAT



