#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <omp.h>

int
main(int argc, char **argv)
{
        int N, Niter, nopt;
	double *X = NULL, *Y = NULL, *Z1 = NULL, *Z2 = NULL;
	double *Z3 = NULL, *Z4 = NULL, *Z5 = NULL;
	double V1, V2, V3, V4, V5, ALPHA;
	double S1time, S2time, S3time, E1time, E2time, E3time;
	int i, ip, iter, iter_o;

/*********
 * INIT. *
 *********/
	fprintf(stdout, "N,Nopt?\n");
	fscanf(stdin, "%d %d", &N, &nopt);

	X = (double *)malloc(sizeof(double)*N);
	if(X == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}
	Y = (double *)malloc(sizeof(double)*N);
	if(Y == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}
	Z1 = (double *)malloc(sizeof(double)*N);
	if(Z1 == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}
	Z2 = (double *)malloc(sizeof(double)*N);
	if(Z2 == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}

	Z3 = (double *)malloc(sizeof(double)*N);
	if(Z3 == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}

	Z4 = (double *)malloc(sizeof(double)*N);
	if(Z4 == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}

	Z5 = (double *)malloc(sizeof(double)*N);
	if(Z5 == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
		goto error;
	}

#pragma omp parallel
 {
}
	if (nopt==0) {for(i=0; i<N; i++) {
		X[i]  = 1.0;
		Y[i]  = 1.0;
		Z1[i] = 0.0;
		Z2[i] = 0.0;
		Z3[i] = 0.0;
		Z4[i] = 0.0;
		Z5[i] = 0.0;}
	}else{
#pragma omp parallel for private(i)
		for(i=0; i<N; i++) {
		        X[i]  = 1.0;
		        Y[i]  = 1.0;
		        Z1[i] = 0.0;
			Z2[i] = 0.0; 
			Z3[i] = 0.0;
			Z4[i] = 0.0;
			Z5[i] = 0.0;
		}
        }

	ALPHA = 1.0;

/*********
 * DAXPY *
 *********/
		/*
		 * omp-1
		 */
		S2time = omp_get_wtime();
#pragma omp parallel for private(i)
		for(i=0; i<N; i++) {
			Z1[i] = ALPHA * X[i] + Y[i];
			Z2[i] = ALPHA * X[i] + Y[i];
			Z3[i] = ALPHA * X[i] + Y[i];
			Z4[i] = ALPHA * X[i] + Y[i];
			Z5[i] = ALPHA * X[i] + Y[i];
		}
		E2time = omp_get_wtime();

		fprintf(stdout, "\n");
		fprintf(stdout, "# DAXPY\n");
		fprintf(stdout, "  omp-1 %16.6E\n", E2time - S2time);

/*******
 * DOT *
 *******/
		/*
		 * omp-1
		 */
		V1 = 0.0;
		V2 = 0.0;
		V3 = 0.0;
		V4 = 0.0;
		V5 = 0.0;
		S2time = omp_get_wtime();
#pragma omp parallel for private(i) reduction(+:V1,V2,V3,V4,V5)
		for(i=0; i<N; i++) {
  		    V1 += X[i] * (Y[i]+1.0);
  		    V2 += X[i] * (Y[i]+2.0);
  		    V3 += X[i] * (Y[i]+3.0);
  		    V4 += X[i] * (Y[i]+4.0);
  		    V5 += X[i] * (Y[i]+5.0);
		}
		E2time = omp_get_wtime();

		fprintf(stdout, "\n");
		fprintf(stdout, "# DOT\n");
		fprintf(stdout, "  omp-1 %16.6E\n", E2time - S2time);


	return 0;

error:
	free(X);
	free(Y);
	free(Z1);
	free(Z2);
	free(Z3);
	free(Z4);
        free(Z5);
	return -1;
}
